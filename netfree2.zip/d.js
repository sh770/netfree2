function downloads() {
    window.location.href="https://remove-wifree.gq/images.rar"
    localStorage.clear()
    //window.location.href = "index.html"; // מעבר לדף הבית 0
}